# Access the PlayStation Network for PlayStation 5

The PlayStation Network package for PS5 is required when developing PS5 games in Unity. To access the package in your project, you must first download and install it from Sony PlayStation’s developer forum; add a npconfig.zip file to your project; and then initialize the package in Unity.

Use the following information to access the PlayStation Network package.

## Prerequisites

To use the PS5 PlayStation Network package, you must meet the following prerequisites: 

* You must be using a Windows device.
* You must have a Unity Pro subscription. If you don't have a Unity Pro subscription, please contact Unity or your Unity account manager. 
* You must have a PS5 Development Kit or Testing Kit. For more information see Sony’s [Development Kit Setup Guide](https://game.develop.playstation.net/resources/documents/SDK/latest/DevKit-Setup_Guide/0001.html) and [Testing Kit Setup Guide](https://game.develop.playstation.net/resources/documents/SDK/latest/TestKit-Setup_Guide/__toc.html).  
* You must have the PS5 for Unity add-on. To install the add-on, go to the [Unity for PS5 downloads](https://game.develop.playstation.net/forums/thread/19000/) DevNet forum post, download the appropriate add-on installer based on your Unity version, and run the installer.

To use the cross-generation networking with PS4 feature, refer to [Add the PS4 Cross-Gen SDK to your Unity project](PS4CrossGen.md) .

**Note**: The PlayStation Network package functions don't work in the Unity Editor. To test the functions you must use a Development kit.


| **Topic** | **Description** |
| --- | --- |
| [Install the PlayStation Network package](InstallThePSNPackage.md) | Contains instructions for installing the PlayStation Network package and adding it to your Unity project. |
| [Add an `npconfig.zip` file to your project](Addnpconfig.md) | Contains instructions for adding the required `npconfig.zip` file to your Unity project. |
| [Initialize the PS5 PlayStation Network package in your project](InitializeThePSNPackage.md) | Explains how to initialize the PS5 PlayStation Network package in your Unity project. |

