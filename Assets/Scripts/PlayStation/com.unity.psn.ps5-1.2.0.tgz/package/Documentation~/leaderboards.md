# Leaderboards

Leaderboards are a PlayStation Network (PSN) service that lets you upload and display player scores gained in your titles. 

You can create multiple leaderboards with individual controls to set the number of users that can record scores, specific conditions and rules for updating scores, and whether to sort the displayed scores in ascending or descending order. When recording a score, you can attach custom data at the same time. This custom data can store contextual game data, such as character information from when the player achieved the high-score, or larger data such as a ghost replay data or a screenshot.

For further information on setting up leaderboards, refer to the [Leaderboards overview](https://game.develop.playstation.net/resources/documents/WebAPI/1/Leaderboards-Overview/__toc.html) on DevNet.

## Using leaderboards with Unity

To use leaderboards in your title, you must apply for the service via [DevNet](https://game.develop.playstation.net/resources/documents/SDK/latest/PSN_Service_Setup-Guide/requesting-to-add-a-new-service-for-a-new.html). After applying for the service, you will have access to the [Leaderboards Tool](https://game.develop.playstation.net/resources/documents/WebAPI/1/Leaderboards-Overview/0003.html#__document_toc_00000009), allowing you to set-up and configure your leaderboards.

### Sample Project

A sample project is provided inside the PSN package. The sample project has code samples specifically for interacting with the Leaderboards utility. To access the sample project, use the following steps:

1. Import the PSN sample from **Window** > **Package manager** > **PS5 PlayStation Network**. 
1. In the samples tab, select Import for the PSN Sample.
1. Once imported, in the Project window, navigate to `Assets/Samples/PSN Sample/SonyExamples/NP` and open the C# file named `SonyLeaderboards`.

The sample code in the `SonyLeaderboards` file is an example workflow of how you can achieve the following:

* Retrieve a leaderboard.
* Record a score on the leaderboard with small data.
* Handle a temporary rank.
* Record a score using Large Data.
* Retrieve the users ranking position on the leaderboard.

For an example of recording a score to a leaderboard, refer to the following sample code:

```csharp
if (m_MenuLeaderboards.AddItem("Record Score", "Record a score on the board", enabled))
    {
        Int64 score = (Int64)UnityEngine.Random.Range(0, 1000);

        Leaderboards.RecordScoreRequest request = new Leaderboards.RecordScoreRequest()
        {
            UserId = GamePad.activeGamePad.loggedInUser.userId,
            BoardId = 1,
            Score = score,
            NeedsTmpRank = true,
            Comment = "Sample app score",
            SmallData = MakeData(30, (byte)score),
        };

        var requestOp = new AsyncRequest<Leaderboards.RecordScoreRequest>(request).ContinueWith((antecedent) =>
        {
            if (SonyNpMain.CheckAysncRequestOK(antecedent))
            {
                OnScreenLog.Add("TmpRank : " + antecedent.Request.TmpRank);
                OnScreenLog.Add("TmpSerialRank : " + antecedent.Request.TmpSerialRank);
            }
        });

        OnScreenLog.Add("Recording score... " + score);

        Leaderboards.Schedule(requestOp);
    }
```

### Adding additional data
You can use the `SmallData` and `LargeData` properties to add additional information to the Leaderboard when recording a score. The `SmallData` property has a maximum string length of 256.

Use `LargeData` to record ghost replays or a screenshot and has a maximum size of 1 MiB per instance and 1 GiB or less in total. These maximum sizes are displayed in the Leaderboards Tool. Navigate to **Define Leaderboards** and the total amount of used and available large data will be visible under T**otal Size of Large Data on Customized Leaderboards**. 

When adding any LargeData to a request, you can only record data for scores ranked higher than the value of `LargeDataNumLimit` that's set for this leaderboard. Only players positioned at this rank or better can record such data. When posting a score, a [temporary rank](https://game.develop.playstation.net/resources/documents/WebAPI/1/Leaderboards-Overview/0003.html#__document_toc_00000010) is returned. Use this temporary rank value to find out if the score ranks above the `LargeDataNumLimit`, and from there decide whether to add any additional `LargeData` to the posted score.

For more information on attaching and retrieving additional data, refer to [Obtain Attachment Data](https://game.develop.playstation.net/resources/documents/WebAPI/1/Leaderboards-Overview/0003.html#__document_toc_00000010).

### Web APIs

Unity’s scripting API for Leaderboards interacts directly with Sony's Leaderboards Web API. For a full list of all Sony’s leaderboard Web API endpoints, refer to [Leaderboards Web API Reference](https://game.develop.playstation.net/resources/documents/WebAPI/1/Leaderboards_WebAPI-Reference/__toc.html).

### Script reference
For a full breakdown of the available classes and properties available in Unity to access the leaderboards service, refer to [Unity.​PSN.​PS5.​Leaderboard
](xref:Unity.PSN.PS5.Leaderboard).

## Additional resources

* [Leaderboards Overview](https://game.develop.playstation.net/resources/documents/WebAPI/1/Leaderboards-Overview/__toc.html)
* [Leaderboards Management Web API Overview](https://game.develop.playstation.net/resources/documents/WebAPI/1/Leaderboards_Management_WebAPI-Overview/__toc.html)

