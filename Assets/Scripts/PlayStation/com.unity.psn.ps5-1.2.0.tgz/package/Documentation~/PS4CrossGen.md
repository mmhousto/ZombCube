# Add the PS4 Cross-Gen SDK to your Unity project

The PlayStation 4 (PS4) Cross-Gen Software Development Kit (SDK) enables you to add PlayStation 5 (PS5) network functionality to a PS4 game, allowing for cross-generation networking between PS4 and PS5 players while playing your PS4 game and vice versa. The SDK provides APIs for PS5 network features such as multiplayer, social platform, commerce platform, and data platform. For more information about the features that are included, see[ Cross-Generation SDK](https://game.develop.playstation.net/resources/documents/sdk/latest/Cross_Generation-Overview/0003.html) .

## Prerequisites

Before setting up the PS4 Cross-Gen SDK, make sure you have completed the following actions:

* You must have a Unity Pro subscription. If you don't have a Unity Pro subscription, please contact Unity or your Unity account manager. 
* Follow the steps in [Access the PlayStation Network](AccessThePSNPackage.md) to download and install the PS5 PlayStation Network package.
* Download and install the PS4 add-on for your Unity version. Download this add-on from [DevNet](https://game.develop.playstation.net/resources/documents/sdk/latest/Cross_Generation-Overview/0004.html).
* Download and install the PS4 PlayStation Network package from DevNet. This package is required for when you want to call functions using the PS4 Cross-Gen SDK.

| **Topic** | **Description** |
| --- | --- |
| [Set up the PS4 Cross-Gen SDK](PS4CrossGenSetup.md) | Contains guidance for installing and adding the PS4 Cross-Gen SDK to your Unity project. |