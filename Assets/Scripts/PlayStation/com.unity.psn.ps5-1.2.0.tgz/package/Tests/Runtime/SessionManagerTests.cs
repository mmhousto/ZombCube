#if UNITY_PS5
using System.Collections;
using NUnit.Framework;
using PSNTests;
using Unity.PSN.PS5.Aysnc;
using Unity.PSN.PS5.Sessions;
using UnityEngine;
using UnityEngine.TestTools;

namespace PSNTests
{
    [TestFixture, Description("Check session manager tests")]
    public class SessionManagerTests : BaseTests
    {
        [UnityTest, Order(1), Description("Can Register Session Manager Events")]
        public IEnumerator RegisterSessionManagerEvents()
        {
            var op = SessionsManager.RegisterUserSessionEvent(GetMainUserId());
            yield return new WaitUntil(() => IsCompleted(op) == true);
            Assert.NotNull(SessionsManager.GetUserSessionPushEvent(GetMainUserId()));
        }

        [UnityTest, Order(2), Description("Can Register Session Manager Events")]
        public IEnumerator UnRegisterSessionManagerEvents()
        {
            //Ensure that the event is currently registered
            if (SessionsManager.GetUserSessionPushEvent(GetMainUserId()) == null)
            {
                yield return RegisterSessionManagerEvents();
            }

            var op = SessionsManager.UnregisterUserSessionEventAsync(GetMainUserId());
            yield return new WaitUntil(() => IsCompleted(op) == true);
            Assert.IsNull(SessionsManager.GetUserSessionPushEvent(GetMainUserId()));
        }

        public bool IsCompleted(AsyncOp op)
        {
            Assert.IsNotNull(op, "AsyncOp is Null");

            return op.IsCompleted;
        }
    }
}
#endif
