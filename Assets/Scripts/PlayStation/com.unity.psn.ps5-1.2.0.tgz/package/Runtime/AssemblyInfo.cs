using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.PSN.PS5.Editor")]
[assembly: InternalsVisibleTo("Unity.PSN.PS5.Tests.Editor")]
