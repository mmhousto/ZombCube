
namespace Unity.PSN.PS5
{
    internal static class LibraryInfo
    {
        internal const string LibraryName = "PSN";
        internal static string LibraryNameWithExtension => $"{LibraryName}.prx";
    }
}
