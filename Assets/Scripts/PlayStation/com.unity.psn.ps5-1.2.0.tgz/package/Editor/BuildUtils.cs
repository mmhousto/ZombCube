#if UNITY_EDITOR_WIN
using System;
using System.IO;
using System.Text.RegularExpressions;
using UnityEditor;

internal static class BuildUtils
{
    internal static readonly string kBuildFolderName = "Build";

    internal static bool HaveSourceFilesBeenModifiedSince(string sourcePath, DateTime lastPrxWrite)
    {
        DateTime latestWriteTime = DateTime.MinValue;
        DirectoryInfo di = new DirectoryInfo(sourcePath);
        foreach (var file in  di.GetFiles("*.cpp", SearchOption.AllDirectories))
        {
            var fileLW = File.GetLastWriteTimeUtc(file.FullName);
            latestWriteTime = (fileLW > latestWriteTime) ? fileLW: latestWriteTime;
        }
        foreach (var file in  di.GetFiles("*.h", SearchOption.AllDirectories))
        {
            var fileLW = File.GetLastWriteTimeUtc(file.FullName);
            latestWriteTime = (fileLW > latestWriteTime) ? fileLW: latestWriteTime;
        }

        System.Console.WriteLine($"latestWriteTime:{latestWriteTime} lastwritepre:{lastPrxWrite}");
        if (latestWriteTime < lastPrxWrite)
        {
            System.Console.WriteLine($"skipping package prebuild step. No changes detected");
            return false;
        }

        return true;
    }

    internal static string GetStagingAreaLocationFor(BuildTarget buildPlatform, string projectDir, string outputPath)
    {
        string stagingArea;

        //2021.3 (pre-IBP) has StagingArea as a root to just the StagingArea Folder
        //2022 (IBP) uses the [BUILD_OUTPUT]/Build path as its StagingArea and ignores the staging area
        //completely
#if UNITY_2022_2_OR_NEWER
        if (buildPlatform == BuildTarget.PS4)
        {
            stagingArea = Path.Combine(outputPath, kBuildFolderName, "Media", "Plugins");
        }
        else if (buildPlatform == BuildTarget.PS5)
        {
            stagingArea = Path.Combine(projectDir, "Temp", "StagingArea", "User", "Media", "Plugins");
        }else
        {
            throw new InvalidOperationException($"Cannot get staging area for {buildPlatform}");
        }
#else
        //PS4 will auto copy the contents of Data to the media folder and if you have already created a media folder
        //(i.e. StagingArea/Media) it will throw an error, so instead just copy to data and allow the PS4 build process to
        //do the copying to Media
        if (buildPlatform == BuildTarget.PS4)
        {
            stagingArea = Path.Combine(projectDir, "Temp", "StagingArea", "Data", "Plugins");
        }
        else if (buildPlatform == BuildTarget.PS5)
        {
            stagingArea = Path.Combine(projectDir, "Temp", "StagingArea", "Media", "Plugins");
        }
        else
        {
            throw new InvalidOperationException($"Cannot get staging area for {buildPlatform}");
        }
#endif

        return stagingArea;
    }

}
#endif
