#if UNITY_EDITOR_WIN
using System;
using System.IO;
using System.Text.RegularExpressions;
using UnityEditor;

internal static class SDKUtils
{
    internal static string GetSDKVersionString(BuildTarget target)
    {
        string verstring = string.Empty;
        string sdkPath = System.Environment.GetEnvironmentVariable(GetSdkEnvVarFor(target));
        if (sdkPath != null)
        {
            string versionFile = Path.Combine(sdkPath, "target/include/sdk_version.h");
            if (File.Exists(versionFile))
            {
                string[] lines = File.ReadAllLines(versionFile);
                foreach (string line in lines)
                {
                    //Extract the value following #define SCE_PROSPERO_SDK_VERSION
                    string regexPattern = $@"#define\s+{GetSdkVersionStringFor(target)}\s+\(\s*0x([0-9a-fA-F]+)u\s*\)";
                    Match match = Regex.Match(line, regexPattern);
                    if (match.Success)
                    {
                        verstring = match.Groups[1].Value;
                    }
                }
            }
        }

        return verstring;
    }

    internal static string GetSdkEnvVarFor(BuildTarget target)
    {
        switch (target)
        {
#if !PSN_DISABLE_PS4_CROSS_GEN_COMPILATION
            case BuildTarget.PS4:
                return "SCE_ORBIS_SDK_DIR";
#endif
            case BuildTarget.PS5:
                return "SCE_PROSPERO_SDK_DIR";
            default:
                throw new InvalidOperationException($"Cannot get env var for {target}");
        }
    }

    internal static string GetClangFor(BuildTarget target)
    {
        switch (target)
        {
#if !PSN_DISABLE_PS4_CROSS_GEN_COMPILATION
            case BuildTarget.PS4:
                return "orbis-clang.exe";
#endif
            case BuildTarget.PS5:
                return "prospero-clang.exe";
            default:
                throw new InvalidOperationException($"Cannot get clang for {target}");
        }
    }

    static string GetSdkVersionStringFor(BuildTarget target)
    {
        switch (target)
        {
#if !PSN_DISABLE_PS4_CROSS_GEN_COMPILATION
            case BuildTarget.PS4:
                return "SCE_ORBIS_SDK_VERSION";
#endif
            case BuildTarget.PS5:
                return "SCE_PROSPERO_SDK_VERSION";
            default:
                throw new InvalidOperationException($"Cannot get SDK for {target}");
        }
    }
}
#endif
